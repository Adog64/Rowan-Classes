extern "C" {
  int24_t fp_mul(int24_t x, int24_t y);
  int24_t fp_sqr(int24_t x);
}